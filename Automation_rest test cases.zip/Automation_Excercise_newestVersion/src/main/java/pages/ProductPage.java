package pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductPage extends PageBase {

	public ProductPage(WebDriver driver) {
		super(driver);

	}
	
	@FindBy(xpath = "//h2[@class='title text-center']")
	public WebElement productsMessage;
	///html/body/section[2]/div/div/div[2]/div/h2/text()
	
	@FindBy(xpath="/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[2]/ul/li/a")
	 WebElement viewProductBtn;
	
	@FindBy(id="accordian")
	public WebElement CategoryList;
	
	@FindBy(xpath="/html/body/section[2]/div/div/div[1]/div/div[3]")
	public WebElement BrandsList;
	
	@FindBy(xpath="//h2[normalize-space()='Blue Top']")
	public WebElement productName;
	//"/html/body/section/div/div/div[2]/div[2]/div[2]/div/h2"
	
	@FindBy(xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[1]")
	public WebElement productCategory;
	
	@FindBy(xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/span")
	public WebElement productPrice;
	
	@FindBy(xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]/b")
	public WebElement productAvailability;
	
	@FindBy(xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]/b")
	public WebElement productCondition;
	
	@FindBy(xpath="/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]/b")
	public WebElement productBrand;
	
	@FindBy(id="name")
	public WebElement nameToReview;
	
	@FindBy(id="email")
	public WebElement emailToReview;
	
	@FindBy(id="review")
	public WebElement messageToReview;
	
	@FindBy(id="search_product")
	public WebElement searchProductBox;
	
	@FindBy(id="submit_search")
	 WebElement searchBtn;
	
	@FindBy(id="button-review")
	 WebElement reviewBtn;
	
	@FindBy(xpath="/html/body/section[2]/div/div/div[2]/div/h2")
	public WebElement searchProductMessage;
	
//	@FindBy(xpath = "//h2[text()='Searched Products']") 
//    WebElement searchedProductsHeader;
	
    @FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div")
    List<WebElement> searchedProductItems;

	
	public void viewProductButton() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// Scroll لعنصر معين
		js.executeScript("document.getElementsByClassName('brands_products')[0].scrollIntoView({ behavior: 'smooth' });");
		// إزالة الإعلان
		js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
		viewProductBtn.click();
	}
	
	public void searchOnProduct(String theProductName) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		searchProductBox.clear();
		searchProductBox.sendKeys(theProductName);
		searchBtn.click();
	}
	
	
	public void wrirteYourReview(String name, String email, String Message) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
//		nameToReview.sendKeys(name);
//		emailToReview.sendKeys(email);
//		messageToReview.sendKeys(Message);
//		reviewBtn.click();

		    if (name != null) {
		        nameToReview.sendKeys(name);
		        System.out.println("Name: " + name);
		    } else {
		        System.out.println("⚠️ name is null");
		    }

		    if (email != null) {
		        emailToReview.sendKeys(email);
		        System.out.println("Email: " + email);
		    } else {
		        System.out.println("⚠️ email is null");
		    }

		    if (Message != null) {
		        messageToReview.sendKeys(Message);
		        System.out.println("Message: " + Message);
		    } else {
		        System.out.println("⚠️ message is null");
		    }

		    reviewBtn.click();
		}

		
	public boolean areAllSearchedProductsDisplayed(String ProductItem ){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		searchProductBox.clear();
   for (WebElement product : searchedProductItems) {
	   if (!product.isDisplayed()) {
		   return false;}
	   }
   return true;

	}
	
	
	
}
