package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckoutAddressPage extends PageBase {

	public CheckoutAddressPage(WebDriver driver) {
		super(driver);
	
	}


	    @FindBy(xpath = "(//a[contains(text(),'Add to cart')])[1]")
	    WebElement firstAddToCartBtn;

	    @FindBy(xpath = "//u[text()='View Cart']")
	    WebElement viewCartBtn;

	    @FindBy(xpath = "//a[contains(text(),'Proceed To Checkout')]")
	    WebElement CheckoutBtn;

	    @FindBy(xpath = "//ul[@id='address_delivery']")
		
		public  WebElement deliveryAddressBox;

	    @FindBy(xpath = "//ul[@id='address_invoice']")
	    public  WebElement billingAddressBox;

	    public void addFirstProductToCart() {
	        firstAddToCartBtn.click();
	        viewCartBtn.click();
	    }

	    public void proceedToCheckout() {
	        CheckoutBtn.click();
	    }

	    public String getDeliveryAddressText() {
	      return deliveryAddressBox.getText();
	      
	    }

	    public String getBillingAddressText() {
	    	return billingAddressBox.getText();
	    }

	}


