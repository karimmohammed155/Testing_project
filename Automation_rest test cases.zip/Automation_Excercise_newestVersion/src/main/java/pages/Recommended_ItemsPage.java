package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v133.page.Page;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.JavascriptExecutor;
import java.time.Duration;
import java.util.List;

public class Recommended_ItemsPage extends PageBase {

	public Recommended_ItemsPage(WebDriver driver) {
		super(driver);
		
	}

@FindBy(className = "class=\"recommended_items\"")
	    List<WebElement> recommendedItems;

@FindBy(xpath = "//div[@id='recommended-item-carousel']//a[contains(text(),'Add to cart')]")
        List<WebElement> addToCartBtns;

@FindBy(xpath = "//u[text()='View Cart']")
	    WebElement viewCartBtn;

public void scrollToRecommendedSection() {
	      JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		  js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		  js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
	      js.executeScript("document.getElementsByClassName('recommended_items')[0].scrollIntoView({ behavior: 'smooth' });");
	      // js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	  }

public boolean isRecommendedItemsVisible() {
	for (WebElement Item : recommendedItems) {
	    if (!Item.isDisplayed()) {
	      return false;}
	 }
	     return true;
	    }

public void addToCartFromRecommended() {
	for (WebElement btn : addToCartBtns) { 
		if (btn.isDisplayed() && btn.isEnabled()) {
			btn.click();
		break;
		}
}
   }



public void clickViewCart() {
	 viewCartBtn.click();
      }

	}



