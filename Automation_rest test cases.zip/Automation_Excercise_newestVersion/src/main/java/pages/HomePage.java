package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBase {

	public HomePage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(linkText = "Signup / Login")
	WebElement signUpBtn;
	
	@FindBy(linkText = "Home")
	public WebElement homeLink;
	
	@FindBy(linkText = "Contact us")
	WebElement contactUsBtn;
	
	@FindBy(xpath = "//a[@href='/products']")
	WebElement productBtn;
	
	@FindBy(xpath = "//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[5]/a")
	WebElement testCasesBtn;
	
	public void openRegisterationPage() {
		signUpBtn.click();
	}
	
	public void openLoginPage() {
		signUpBtn.click();
	}
	
	public void openContactUsPage() {
		contactUsBtn.click();
	}
	
	public void openHomePage() {
		homeLink.click();
	}
	public void openProductPage() {
		productBtn.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("let ad = document.querySelector('.adsbygoogle'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.adsbygoogle-noablate'); if(ad) { ad.remove(); }");
		js.executeScript("let ad = document.querySelector('.grippy-host'); if(ad) { ad.remove(); }");
	}
	
	public void opentestCasespage() {
		testCasesBtn.click();
	}
}
