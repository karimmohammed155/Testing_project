package tests;

import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_happyAndnegativeScenarioWithDDTAndDataProvider extends TestBase{
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
	
	@DataProvider(name="LoginData")
	public Object[][] testData(){
		Object[][] data = new Object[][] {
			{"samirnasser123@gmail.com","123456789",true},
			{"samirnasser3@gmail.com","123456789",false},
			{"samirnasser123@gmail.com","123456",false}
		};
		
		return data;
	};
	
  @Test (dataProvider = "LoginData")
  public void testLogin_CorrectUsernameAndPassword(String email,String password,boolean success) throws InterruptedException {
	  homeObject.openHomePage();
	  
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  homeObject.openLoginPage();
	  
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText()); 
	  
	  loginObject.userCanLogin(email, password);
	  
	  if(success) {
			Assert.assertEquals("Logout", loginObject.logoutBtn.getText());
			loginObject.userCanLogout();
	  }  
	  else 
		  Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());

  }
}
