package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_happyScenarioWithDDTAndDataProvider extends TestBase{
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
	
	@DataProvider(name="LoginHappyData")
	public Object[][] testData(){
		Object[][] data = new Object[][] {
			{"abdelrahmanosama76845111@gmail.com","123456789"},
			{"abdelrahmanosama7651@gmail.com","12345678"}
		};
		
		return data;
	};
	
  @Test (dataProvider = "LoginHappyData")
  public void testLogin_CorrectUsernameAndPassword(String email,String password) throws InterruptedException {
	  homeObject.openHomePage();
	  
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  homeObject.openLoginPage();
	  
	  Thread.sleep(3000);
	  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText()); 
	  
	  loginObject.userCanLogin(email, password);
	  Thread.sleep(3000);
	  
	  loginObject.userCanLogout();
	  Thread.sleep(3000);
  }
}
