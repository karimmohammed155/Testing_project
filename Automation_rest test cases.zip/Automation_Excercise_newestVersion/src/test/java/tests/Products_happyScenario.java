package tests;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import data.LoadLoginProperties;
import data.LoadReviewProperties;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductPage;

public class Products_happyScenario extends TestBase{
	HomePage homeObject = new HomePage(driver);
	ProductPage productObject = new ProductPage(driver);
	
	String name =LoadReviewProperties.reviewData.getProperty("name");
	String email = LoadReviewProperties.reviewData.getProperty("email");
	String reviewMessage = LoadReviewProperties.reviewData.getProperty("reviewMessage");
	String productsCategory = LoadReviewProperties.reviewData.getProperty("productsCategory");
	String productName = LoadReviewProperties.reviewData.getProperty("productName");
	
  @Test
  public void testProductPage() throws InterruptedException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
	  Thread.sleep(3000);
	  
	  homeObject.openProductPage();
	  Assert.assertEquals("ALL PRODUCTS", productObject.productsMessage.getText());
	  Thread.sleep(3000);
	  
	  Assert.assertTrue(productObject.CategoryList.isDisplayed(), "Category list is not visible");
	  Assert.assertTrue(productObject.BrandsList.isDisplayed(), "Brands list is not visible");
	  
	  productObject.searchOnProduct(productName);
	  Assert.assertEquals("SEARCHED PRODUCTS", productObject.searchProductMessage.getText());
	  Thread.sleep(2000);
	  driver.navigate().back();
	  
	  productObject.searchOnProduct(productsCategory);
	  Assert.assertTrue(productObject.areAllSearchedProductsDisplayed(productsCategory));
	  Thread.sleep(3000);
	  
	  driver.navigate().back();
	  productObject.viewProductButton();
	  Thread.sleep(3000);
	  
	  Assert.assertTrue(productObject.productName.isDisplayed());
	  Assert.assertTrue(productObject.productCategory.isDisplayed());
	  Assert.assertTrue(productObject.productPrice.isDisplayed());
	  Assert.assertTrue(productObject.productAvailability.isDisplayed());
	  Assert.assertTrue(productObject.productCondition.isDisplayed());
	  Assert.assertTrue(productObject.productBrand.isDisplayed());
	  
	  productObject.wrirteYourReview(name, email, reviewMessage);
	  Thread.sleep(3000);
	  
	  homeObject.homeLink.click();
  }
}
