package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class Login_negativeScenarioWithDDTAndDataProvider extends TestBase{
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
	
	@DataProvider(name="LoginNegativeData")
	public Object[][] testData(){
		Object[][] data = new Object[][] {
			{"abdelrahmanosama7684111@gmail.com","1234567"},
			{"abdelrahmanosama7654@gmail.com","12345678"}
		};
		
		return data;
	};
	
  @Test(dataProvider = "LoginNegativeData")
  public void testLogin_CorrectUsernameAndInCorrectPassword(String email,String password) throws InterruptedException {
	  homeObject.openHomePage();
	  
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  homeObject.openLoginPage();
	  
	  Thread.sleep(3000);
	  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText()); 
	  
	  loginObject.userCanLogin(email, password);
	  Thread.sleep(3000);
	 
	  Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());

  }
  
//  @Test
//  public void testLogin_InCorrectUsername() throws InterruptedException {
//	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
//	  homeObject.openLoginPage();
//	  
//	  Thread.sleep(3000);
//	  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText()); 
//	  
//	  loginObject.userCanLogin("abdelrahmanosama7684@gmail.com", "123456789");
//	  Thread.sleep(3000);
//	 
//	  Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());
//
//  }
}
