package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class Register_negativeScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	RegisterPage registerPage = new RegisterPage(driver);
  @Test (priority = 2)
  public void Register_ExistEmail() throws InterruptedException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  
	  Thread.sleep(3000);
	  homeObject.openRegisterationPage();
	  
	  Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
	  Thread.sleep(3000);
	  
	  String name ="Abdelrahman Osama";
	  registerPage.userCanRegister(name,"abdelrahmanosama768@gmail.com");
	  
	  Thread.sleep(3000);
	  
	  Assert.assertEquals("Email Address already exist!", registerPage.failedMessage.getText());
  }
}
