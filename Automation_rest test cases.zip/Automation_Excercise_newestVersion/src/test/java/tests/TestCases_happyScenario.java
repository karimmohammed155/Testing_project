package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.TestCasesPage;

public class TestCases_happyScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	  TestCasesPage testcaseObject = new TestCasesPage(driver);
  @Test
  public void testTestCases() throws InterruptedException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
	  Thread.sleep(3000);
	  homeObject.opentestCasespage();
	  
	  Assert.assertTrue(testcaseObject.testCaseMessage.getText().equalsIgnoreCase("Test Cases"));

  }
}
