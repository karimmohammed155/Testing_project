package tests;

import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ContactUsPageWtihDirectWay;
import pages.ContactUsPageWtihRobotClass;
import pages.HomePage;

public class ContactUs_happyScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ContactUsPageWtihRobotClass contactUsObject = new ContactUsPageWtihRobotClass(driver);
  @Test
  public void testContactUs_ValidData() throws InterruptedException, AWTException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  Thread.sleep(3000);
	  
	  homeObject.openContactUsPage();
	  
	  Assert.assertTrue(contactUsObject.contactUsMessage.getText().equalsIgnoreCase("Get In Touch"));
	  
	  contactUsObject.userCanContactUs("Abdelrahman Osama", "adelrahmanfaga@gmail.com", "Complain", "My order doesn't deliver yet");
	  
	  Thread.sleep(3000);
	  
	  Assert.assertEquals("Success! Your details have been submitted successfully.", contactUsObject.successMessage.getText()); ;

  }
}
