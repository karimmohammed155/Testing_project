package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class Register_happyScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	RegisterPage registerPage = new RegisterPage(driver);
  @Test (priority = 1)
  public void Register_NewEmail_MandatoryAndOptional() throws InterruptedException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  
	 
	  homeObject.openRegisterationPage();
	  
	  Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
	
	  
//	  String name ="Abdelrahman Osama";
//	  registerPage.userCanRegister(name,"abdelrahmanosama7658451112@gmail.com");
//	  
//	  Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerPage.enterAccountMessage.getText());
//
//	
//	  registerPage.enterAccountInformation("123456789","25","April","2002","Abdelrahman"
//			  ,"Osama","Itworx","Fostat","Elsayeda","0",
//			  "aaaa","bbbb","176111","01013440054");
//	  
//	  Assert.assertTrue(registerPage.successMessage.getText().equalsIgnoreCase("Account Created!"));
//
//	  
//	  registerPage.continueAccount();
	  
	  
	 // Assert.assertEquals("Logged in as "+name, registerPage.loggedInLink.getText());
	  
	  registerPage.deleteAccount();
	  
	  Assert.assertEquals("ACCOUNT DELETED!", registerPage.deleteMessage.getText());
	  
	  registerPage.continueAccount();
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;

  }
}
