package tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import data.LoadRegisterProperties;
import pages.CheckoutAddressPage;
import pages.HomePage;
import pages.Recommended_ItemsPage;
import pages.RegisterPage;

public class CheckoutAddress_happyScenario extends TestBase {
	Recommended_ItemsPage recommendedPage = new Recommended_ItemsPage(driver);
	CheckoutAddressPage checkoutPage = new CheckoutAddressPage(driver);
	HomePage homeObject = new HomePage(driver);
	RegisterPage registerPage = new RegisterPage(driver);
	
	String name = LoadRegisterProperties.registerData.getProperty("name");
	String email = LoadRegisterProperties.registerData.getProperty("email");
	boolean success = Boolean.parseBoolean(LoadRegisterProperties.registerData.getProperty("success"));
	String password = LoadRegisterProperties.registerData.getProperty("password");
	String day = LoadRegisterProperties.registerData.getProperty("day");
	String month = LoadRegisterProperties.registerData.getProperty("month");
	String year = LoadRegisterProperties.registerData.getProperty("year");
	String firstName = LoadRegisterProperties.registerData.getProperty("firstName");
	String lastName = LoadRegisterProperties.registerData.getProperty("lastName");
	String company = LoadRegisterProperties.registerData.getProperty("company");
	String address1 = LoadRegisterProperties.registerData.getProperty("address1");
	String address2 = LoadRegisterProperties.registerData.getProperty("address2");
	String countryIndex = LoadRegisterProperties.registerData.getProperty("countryIndex");
	String state = LoadRegisterProperties.registerData.getProperty("state");
	String city = LoadRegisterProperties.registerData.getProperty("city");
	String zipCode = LoadRegisterProperties.registerData.getProperty("zipCode");
	String mobilNumber = LoadRegisterProperties.registerData.getProperty("mobilNumber");

    @Test(priority = 2)
    public void verifyAddressDetailsInCheckout() {
    	
//        checkoutPage.addFirstProductToCart();
    	recommendedPage.scrollToRecommendedSection();

        Assert.assertTrue(recommendedPage.isRecommendedItemsVisible(), "'RECOMMENDED ITEMS' section is not visible");

        recommendedPage.addToCartFromRecommended();
        recommendedPage.clickViewCart();
        checkoutPage.proceedToCheckout();
        
        Assert.assertTrue(checkoutPage.getDeliveryAddressText().contains(name),"Delivery address mismatch");
        Assert.assertTrue(checkoutPage.getBillingAddressText().contains(name),"Delivery address mismatch");
        System.out.println("Delivery Address: " + checkoutPage.getDeliveryAddressText());
        System.out.println("Billing Address: " + checkoutPage.getBillingAddressText());

        registerPage.deleteAccount();
  	  Assert.assertEquals("ACCOUNT DELETED!", registerPage.deleteMessage.getText());
  	  
  	  
  	  registerPage.continueAccount();
  	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
    }
    
 
    @Test (priority = 1)
    public void Register_NewEmail_MandatoryAndOptional() throws InterruptedException {
  	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
  	  
  	 
  	  homeObject.openRegisterationPage();
  	  
  	  Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
  	
  	  
  	  registerPage.userCanRegister(name,email);
  	  if(success) {
  		  Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
  		  registerPage.signUpBtn();;
  	  }  
  	  else 
  		  Assert.assertEquals("Email Address already exist!", registerPage.failedMessage.getText());
  	  
  	 Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerPage.enterAccountMessage.getText());
  	  registerPage.enterAccountInformation(password,day,month,year,firstName
  			  ,lastName,company,address1,address2, countryIndex
  			  ,state,city,zipCode,mobilNumber);
  	  
  	  Assert.assertTrue(registerPage.successMessage.getText().equalsIgnoreCase("Account Created!"));

  	  
  	  registerPage.continueAccount();
  	  Assert.assertEquals("Logged in as "+name, registerPage.loggedInLink.getText());
  	  }
}
