package tests;

import java.io.IOException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import data.LoadExcelLoginData;
import data.LoadLoginProperties;
import pages.HomePage;
import pages.LoginPage;

public class Login_happyAndnegativeScenarioWithDDTAndExcelSheet extends TestBase{
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);

	@DataProvider(name="LoginData")
	public Object[][] getExcelLoginData() throws IOException{
		LoadExcelLoginData loginData = new LoadExcelLoginData();		
		return loginData.getExcelLoginData();
	}
	
  @Test (dataProvider = "LoginData")
  public void testLogin_AllLoginTestCases(String email,String password,String success) throws InterruptedException {
	  homeObject.openHomePage();
	  
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  homeObject.openLoginPage();
	  
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	  Assert.assertEquals("Login to your account", loginObject.loginMessage.getText()); 
	  
	  loginObject.userCanLogin(email, password);
	
	  if(success.equalsIgnoreCase("TRUE")) {
			Assert.assertEquals("Logout", loginObject.logoutBtn.getText());
			loginObject.userCanLogout();
	  }  
	  else 
		  Assert.assertEquals("Your email or password is incorrect!", loginObject.failedMessage.getText());

  }
}
