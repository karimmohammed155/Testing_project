package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.Recommended_ItemsPage;

public class Recommended_ItemsScenario extends TestBase {
	
HomePage homeObject = new HomePage(driver);
Recommended_ItemsPage recommendedPage = new Recommended_ItemsPage(driver);

    @Test
    public void userCanAddRecommendedItemToCart() throws InterruptedException {
    
		Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
  	  Thread.sleep(3000);
  	  
        recommendedPage.scrollToRecommendedSection();

        Assert.assertTrue(recommendedPage.isRecommendedItemsVisible(), "'RECOMMENDED ITEMS' section is not visible");

        recommendedPage.addToCartFromRecommended();
        recommendedPage.clickViewCart();

        Assert.assertTrue(driver.getPageSource().contains("Shopping Cart"), "Cart page is not displayed");
    }
}
